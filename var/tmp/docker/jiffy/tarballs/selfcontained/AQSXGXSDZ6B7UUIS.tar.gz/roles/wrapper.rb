name "wrapper"

description "The wrapper cookbook self contained config Base.1,d2741579bb0ddf6667acf5ce3e45d548.5945c1a99be6e4d68da57abb12bb0ed2"

run_list "recipe[custom::default]"

