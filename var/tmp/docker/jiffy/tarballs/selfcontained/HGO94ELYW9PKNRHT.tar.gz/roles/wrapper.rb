name "wrapper"

description "The wrapper cookbook self contained config Ubuntu/Mongo/Install.2,11ddc08041373af526724ad96327ee00.e527a3ae6bf2c69a605b648fd008e58c"

run_list "recipe[custom::default]"

