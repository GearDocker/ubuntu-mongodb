name "ruby_attr"
description "ruby_attr"
default_attributes(
   :ruby => {
       :build => {
          :version => "1.9.3-p385"
       }
   }
)
