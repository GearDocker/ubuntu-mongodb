#Created by jiffy automatically.

group_name "Ubuntu/Mongo/Install"
group_ref_hash "b9092da3e7c872879d433b314645b8c1"
