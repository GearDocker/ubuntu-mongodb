default['mongodb']['admin'] = {
  'username' => 'admin',
  'password' => '2NCDza6MLjDUm0m',
  'roles' => %w(userAdminAnyDatabase dbAdminAnyDatabase),
  'database' => 'admin'
}

default['mongodb']['users'] = []
